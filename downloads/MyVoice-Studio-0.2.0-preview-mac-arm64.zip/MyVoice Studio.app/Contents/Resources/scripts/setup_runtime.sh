#!/usr/bin/env bash
# The public app bundle is model-free. Install its optional MLX runtime per Mac.
set -euo pipefail
if ! command -v python3.12 >/dev/null; then
  echo "Python 3.12 が必要です: brew install python@3.12" >&2
  exit 1
fi
if ! command -v ffmpeg >/dev/null; then
  echo "FFmpeg が必要です: brew install ffmpeg" >&2
  exit 1
fi
runtime="$HOME/Library/Application Support/MyVoice Studio/runtime/.venv"
mkdir -p "$(dirname "$runtime")"
python3.12 -m venv "$runtime"
"$runtime/bin/python" -m pip install --upgrade pip
"$runtime/bin/python" -m pip install 'mlx-audio[tts]' soundfile huggingface_hub
"$runtime/bin/python" -m pip freeze > "$(dirname "$runtime")/installed-requirements.txt"
echo "MLX Audio の導入が完了しました。アプリの設定からモデルを取得してください。"
