"""Isolated, cancellable model worker. Synthesis runs with offline environment flags."""
import json
import os
from pathlib import Path
import sys
import time

from .audio import join, postprocess
from .core import StudioError, atomic_json, digest
from .engines.qwen import Qwen3TTSEngine
from .models import download, verify_model


def work(action, request_path):
    if action == "synthesize":
        # Python-level network guard in addition to HF offline flags. Model code has no network role.
        def deny_network(event, args):
            if event in {"socket.connect", "socket.connect_ex", "socket.sendto"}:
                raise StudioError("生成中のネットワーク接続を遮断しました。")
        sys.addaudithook(deny_network)
    request = json.loads(Path(request_path).read_text(encoding="utf-8"))
    job = request["job"]
    root = Path(request["root"])
    job_dir = root / "jobs" / job["id"]
    state_path = job_dir / "state.json"
    started = time.monotonic()

    def update(progress, message, **extra):
        atomic_json(state_path, {"status": "running", "progress": round(progress, 3),
                                 "message": message, **extra})

    try:
        if action == "download":
            download(root, job["model_id"], update)
            result = {"output": str(root / "models" / job["model_id"])}
        elif action == "synthesize":
            if os.environ.get("HF_HUB_OFFLINE") != "1":
                raise StudioError("オフライン設定が無効です。")
            model_path = root / "models" / job["model_id"]
            update(.01, "モデルの整合性を確認中")
            manifest = verify_model(model_path)
            engine = Qwen3TTSEngine()
            update(.03, "モデルを読み込み中")
            engine.load_model(model_path)
            reference = Path(request["sample"]["path"])
            if not reference.resolve().is_relative_to(root / "voices") or not reference.is_file():
                raise StudioError("参照音声が見つかりません。")
            if len(request["segments"]) > 300:
                raise StudioError("原稿が長すぎます。分割して生成してください。")
            paths = []
            peak = 0
            cache_dir = root / "cache" / job["profile_id"]
            cache_dir.mkdir(exist_ok=True)
            settings = job["settings"]
            for index, part in enumerate(request["segments"]):
                import hashlib
                key = hashlib.sha256(json.dumps({"text": part["text"], "model": manifest["revision"],
                    "ref": digest(reference), "ref_text": request["sample"]["transcript"],
                    "settings": settings, "seed": job["seed"]+index}, ensure_ascii=False,
                    sort_keys=True).encode()).hexdigest()
                cached = cache_dir / f"{key}.wav"
                if not cached.is_file():
                    raw = job_dir / f"segment-{index}.wav"
                    metrics = engine.synthesize(part["text"], reference, request["sample"]["transcript"],
                                                raw, (job["seed"]+index) % (2**32))
                    peak = max(peak, metrics.get("peak_memory_gb", 0))
                    postprocess(raw, cached, settings)
                    raw.unlink(missing_ok=True)
                paths.append((cached, part["paragraph_end"]))
                update(.05 + .9*(index+1)/len(request["segments"]),
                       f"音声を生成中 {index+1}/{len(request['segments'])}")
            output = root / "outputs" / f"{job['id']}.wav"
            join(paths, output, settings["sentence_gap"], settings["paragraph_gap"])
            engine.unload_model()
            result = {"output": str(output), "peak_memory_gb": peak}
        else:
            raise StudioError("不明な処理です。")
        atomic_json(state_path, {"status": "completed", "progress": 1, "message": "完了",
                                 "elapsed_seconds": round(time.monotonic()-started, 2), **result})
    except StudioError as exc:
        atomic_json(state_path, {"status": "failed", "progress": 0, "message": "失敗", "error": str(exc)})
        raise
    except Exception as exc:
        atomic_json(state_path, {"status": "failed", "progress": 0, "message": "失敗",
                                 "error": f"処理に失敗しました: {type(exc).__name__}。ログを確認してください。"})
        raise


if __name__ == "__main__":
    work(sys.argv[1], sys.argv[2])
