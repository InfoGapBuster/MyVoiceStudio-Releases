from abc import ABC, abstractmethod
from ..core import StudioError


class TTSEngine(ABC):
    @abstractmethod
    def load_model(self, path): ...

    @abstractmethod
    def synthesize(self, text, reference, transcript, destination, seed): ...

    @abstractmethod
    def unload_model(self): ...

    def clone_voice(self, *args, **kwargs):
        return self.synthesize(*args, **kwargs)

    def get_capabilities(self):
        return {"tts": True, "clone": True, "emotion": False, "intonation": False,
                "style": False, "train": False, "convert": False,
                "postprocess": ["speed", "pitch", "volume", "sentence_gap", "paragraph_gap"]}

    def convert_voice(self, *args, **kwargs):
        raise StudioError("このエンジンでは音声変換を実装していません。")

    def train(self, *args, **kwargs):
        raise StudioError("このMac向けの追加学習は未検証のため開始できません。")

    def cancel(self):
        # The application terminates the isolated worker process, including loading.
        self.unload_model()


class UnavailableEngine:
    def get_capabilities(self):
        return {"tts": False, "clone": False, "emotion": False, "intonation": False,
                "style": False, "train": False, "convert": False, "postprocess": []}


class CosyVoiceEngine(UnavailableEngine):
    pass


class VoiceConversionEngine(UnavailableEngine):
    pass


class FineTuningEngine(UnavailableEngine):
    pass
