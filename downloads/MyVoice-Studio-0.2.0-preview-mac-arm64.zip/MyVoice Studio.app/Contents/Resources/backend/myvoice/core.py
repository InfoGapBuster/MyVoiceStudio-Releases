from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import re
import sqlite3
import time
import unicodedata
import uuid


class StudioError(Exception):
    pass


def identifier(value):
    if not isinstance(value, str) or not re.fullmatch(r"[a-f0-9]{32}", value):
        raise StudioError("データIDが不正です。画面を更新して選び直してください。")
    return value


def number(value, low, high):
    try:
        n = float(value)
        if not low <= n <= high:
            raise ValueError()
        return n
    except (ValueError, TypeError):
        raise StudioError(f"数値は {low}〜{high} の範囲で指定してください。") from None


def atomic_json(path, value):
    path = Path(path)
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, allow_nan=False), encoding="utf-8")
    temporary.replace(path)


def digest(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def local_file(value, extensions, max_bytes=512 * 1024 * 1024):
    if not isinstance(value, str) or not value.startswith("/") or "\x00" in value:
        raise StudioError("Mac内のファイルを選択してください。URLは利用できません。")
    path = Path(value).resolve(strict=True)
    if not path.is_file() or path.suffix.lower() not in extensions:
        raise StudioError("対応形式のファイルを選択してください。")
    if path.stat().st_size > max_bytes:
        raise StudioError("ファイルが大きすぎます。512MB以下に分割してください。")
    return path


def plain_markdown(text):
    text = re.sub(r"```.*?```", "", text, flags=re.S)
    text = re.sub(r"!\[[^]]*\]\([^)]*\)", "", text)
    text = re.sub(r"\[([^]]+)\]\([^)]*\)", r"\1", text)
    text = re.sub(r"(?m)^\s{0,3}(?:#{1,6}\s+|>\s*|[-*+]\s+|\d+\.\s+)", "", text)
    return re.sub(r"[*_`~]", "", text).strip()


def prepare_text(text, dictionary):
    text = unicodedata.normalize("NFC", plain_markdown(text))
    # Single pass, longest match first: replacement readings never cascade.
    if dictionary:
        pattern = "|".join(re.escape(k) for k in sorted(dictionary, key=len, reverse=True))
        text = re.sub(pattern, lambda m: dictionary[m[0]], text)
    return text


def segments(text, limit=160):
    result = []
    for paragraph in re.split(r"\n\s*\n", text.strip()):
        sentences = re.findall(r"[^。！？!?\n]+[。！？!?]*|[。！？!?]+", paragraph)
        for sentence in sentences:
            sentence = sentence.strip()
            while sentence:
                cut = min(len(sentence), limit)
                if len(sentence) > limit:
                    candidates = [sentence.rfind(c, 0, limit) for c in "、, ；;"]
                    boundary = max(candidates)
                    if boundary >= limit // 3:
                        cut = boundary + 1
                part, sentence = sentence[:cut].strip(), sentence[cut:].strip()
                if part:
                    result.append({"text": part, "paragraph_end": False})
        if result:
            result[-1]["paragraph_end"] = True
    return result


class Store:
    """Small schema; JSON documents preserve engine-specific fields without UI coupling."""
    def __init__(self, root):
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True, mode=0o700)
        os.chmod(self.root, 0o700)
        for folder in ("voices", "outputs", "jobs", "models", "cache", "datasets"):
            (self.root / folder).mkdir(exist_ok=True, mode=0o700)
        self.db = sqlite3.connect(self.root / "studio.sqlite3", check_same_thread=False)
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.execute("CREATE TABLE IF NOT EXISTS documents (kind TEXT, id TEXT, data TEXT, PRIMARY KEY(kind,id))")
        self.db.execute("PRAGMA user_version=1")
        self.db.commit()

    def put(self, kind, data):
        self.db.execute("INSERT OR REPLACE INTO documents VALUES (?,?,?)",
                        (kind, data["id"], json.dumps(data, ensure_ascii=False, allow_nan=False)))
        self.db.commit()
        return data

    def get(self, kind, key):
        row = self.db.execute("SELECT data FROM documents WHERE kind=? AND id=?", (kind, key)).fetchone()
        if row is None:
            raise StudioError("対象データが見つかりません。画面を更新してください。")
        return json.loads(row[0])

    def list(self, kind):
        rows = self.db.execute("SELECT data FROM documents WHERE kind=? ORDER BY rowid DESC", (kind,)).fetchall()
        return [json.loads(row[0]) for row in rows]

    def delete(self, kind, key):
        self.db.execute("DELETE FROM documents WHERE kind=? AND id=?", (kind, key))
        self.db.commit()

    def new(self, **values):
        return {"id": uuid.uuid4().hex, "created": time.time(), **values}
