"""MyVoice Studio: local application services, independent of model implementations."""
__version__ = "0.1.0"
