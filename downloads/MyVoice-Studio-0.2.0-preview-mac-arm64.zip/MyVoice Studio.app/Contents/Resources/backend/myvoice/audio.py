"""Owned audio pipeline. FFmpeg is always called with fixed argv, never a shell."""
from array import array
import math
from pathlib import Path
import shutil
import subprocess
import sys
import wave

from .core import StudioError, number


def ffmpeg():
    for path in ("/opt/homebrew/bin/ffmpeg", "/usr/local/bin/ffmpeg"):
        if Path(path).is_file():
            return path
    raise StudioError("FFmpegがありません。READMEの初期設定を実行してください。")


def run_ffmpeg(args, timeout=180):
    try:
        result = subprocess.run([ffmpeg(), "-hide_banner", "-loglevel", "error", "-nostdin", "-y", *args],
                                capture_output=True, timeout=timeout, check=False)
    except subprocess.TimeoutExpired:
        raise StudioError("音声処理が時間内に完了しませんでした。短いファイルで再試行してください。") from None
    if result.returncode:
        raise StudioError("音声を処理できませんでした。ファイルの形式・破損・保存先の空き容量を確認してください。")


def input_args(path):
    # Restrict demuxer protocols as well as path validation, preventing playlist/network inputs.
    return ["-protocol_whitelist", "file,pipe", "-i", str(path)]


def normalize(source, target, start=0, end=None):
    start = number(start, 0, 3600)
    args = input_args(source) + ["-ss", str(start)]
    if end is not None:
        duration = number(end, start + 0.1, 3600) - start
        args += ["-t", str(duration)]
    else:
        args += ["-t", "121"]
    run_ffmpeg(args + ["-map", "0:a:0", "-vn", "-af", "loudnorm=I=-23:TP=-2:LRA=11",
                       "-ac", "1", "-ar", "24000", "-c:a", "pcm_s16le", str(target)])
    stats = analyze(target)
    if not 3 <= stats["duration"] <= 120:
        target.unlink(missing_ok=True)
        raise StudioError("参照音声は3〜120秒にしてください。長い録音はトリミングしてください。")
    if stats["rms_db"] < -55:
        target.unlink(missing_ok=True)
        raise StudioError("音声がほぼ無音です。マイク・入力音量を確認してください。")
    return stats


def analyze(path):
    with wave.open(str(path), "rb") as f:
        if f.getsampwidth() != 2 or f.getnchannels() != 1:
            raise StudioError("解析用音声は16bitモノラルWAVである必要があります。")
        rate = f.getframerate()
        samples = array("h", f.readframes(f.getnframes()))
    if sys.byteorder != "little":
        samples.byteswap()
    if not samples:
        raise StudioError("音声ファイルが空です。")
    peak = max(abs(x) for x in samples) / 32768
    rms = math.sqrt(sum(x*x for x in samples) / len(samples)) / 32768
    rms_db = 20 * math.log10(max(rms, 1e-8))
    step = max(1, rate // 50)
    energies = [math.sqrt(sum(x*x for x in samples[i:i+step]) / len(samples[i:i+step])) / 32768
                for i in range(0, len(samples), step)]
    silence = sum(v < 0.008 for v in energies) / len(energies)
    floor = sorted(energies)[int(len(energies)*0.1)]
    stride = max(1, math.ceil(len(samples) / 160))
    waveform = [round(max(abs(x) for x in samples[i:i+stride]) / 32768, 4)
                for i in range(0, len(samples), stride)]
    warnings = []
    if peak >= 0.995:
        warnings.append("クリッピングの可能性があります。録音音量を下げてください。")
    if rms_db < -30:
        warnings.append("録音音量が小さめです。マイクに近づいてください。")
    if silence > .45:
        warnings.append("無音が多めです。不要部分のトリミングを推奨します。")
    return {"duration": round(len(samples)/rate, 3), "peak": peak, "rms_db": round(rms_db, 1),
            "silence_ratio": round(silence, 3), "noise_floor_db": round(20*math.log10(max(floor, 1e-8)), 1),
            "waveform": waveform, "warnings": warnings}


def postprocess(source, target, settings):
    speed = number(settings.get("speed", 1), .5, 2)
    pitch = number(settings.get("pitch", 0), -6, 6)
    volume = number(settings.get("volume", 1), .1, 2)
    factor = 2 ** (pitch / 12)
    tempo = speed / factor
    filters = [f"asetrate=24000*{factor}", "aresample=24000"]
    while tempo < .5:
        filters.append("atempo=0.5")
        tempo /= .5
    while tempo > 2:
        filters.append("atempo=2.0")
        tempo /= 2
    filters += [f"atempo={tempo}", "loudnorm=I=-20:TP=-2:LRA=11", f"volume={volume}", "alimiter=limit=0.95:level=false"]
    run_ffmpeg(input_args(source) + ["-af", ",".join(filters), "-ar", "24000", "-ac", "1", "-c:a", "pcm_s16le", str(target)])


def join(parts, target, sentence_gap=.25, paragraph_gap=.6):
    with wave.open(str(target), "wb") as out:
        out.setparams((1, 2, 24000, 0, "NONE", "not compressed"))
        for i, (path, paragraph_end) in enumerate(parts):
            with wave.open(str(path), "rb") as f:
                if (f.getnchannels(), f.getsampwidth(), f.getframerate()) != (1, 2, 24000):
                    raise StudioError("音声結合時の形式が一致しません。")
                while block := f.readframes(24000):
                    out.writeframesraw(block)
            if i < len(parts)-1:
                gap = paragraph_gap if paragraph_end else sentence_gap
                out.writeframesraw(b"\x00\x00" * int(24000*gap))


def export(source, target, fmt, metadata=True):
    codec = {"wav": ["-c:a", "pcm_s16le"], "mp3": ["-c:a", "libmp3lame", "-q:a", "2"],
             "m4a": ["-c:a", "aac", "-b:a", "192k"]}.get(fmt)
    if codec is None:
        raise StudioError("書き出し形式はWAV・MP3・M4Aから選んでください。")
    args = input_args(source) + codec
    if metadata:
        args += ["-metadata", "comment=AI-generated audio; MyVoice Studio", "-metadata", "encoder=MyVoice Studio"]
    run_ffmpeg(args + [str(target)])
