import json
import math
import os
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest.mock import patch
import wave

from myvoice.audio import analyze, export
from myvoice.core import StudioError, atomic_json, digest, prepare_text, segments
from myvoice.service import Studio
from myvoice.worker import work
from myvoice.models import import_model, verify_model


def tone(path, seconds=4):
    with wave.open(str(path), "wb") as f:
        f.setparams((1, 2, 24000, 0, "NONE", "not compressed"))
        import array
        samples = array.array("h", (int(4000*math.sin(i*2*math.pi*220/24000))
                                     for i in range(seconds*24000)))
        f.writeframes(samples.tobytes())


class FakeEngine:
    calls = 0
    def load_model(self, path): pass
    def synthesize(self, text, reference, transcript, destination, seed):
        FakeEngine.calls += 1
        tone(destination, 1)
        return {"peak_memory_gb": 0.1}
    def unload_model(self): pass


class StudioTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.studio = Studio(self.root / "data")
        self.source = self.root / "reference.wav"
        tone(self.source)

    def tearDown(self):
        self.studio.store.db.close()
        self.tmp.cleanup()

    def test_voice_registration_consent_and_restart(self):
        with self.assertRaises(StudioError):
            self.studio.import_voice(str(self.source), "私", "こんにちは", False)
        profile = self.studio.import_voice(str(self.source), "私", "こんにちは", True)
        sample = profile["samples"][0]
        self.assertAlmostEqual(sample["duration"], 4, places=1)
        self.assertEqual(len(sample["analysis"]["waveform"]), 160)
        added = self.studio.import_voice(str(self.source), "ignored", "もう一度", True,
                                        profile_id=profile["id"])
        self.assertEqual(len(added["samples"]), 2)
        restarted = Studio(self.studio.store.root)
        self.assertEqual(len(restarted.overview()["profiles"][0]["samples"]), 2)
        restarted.store.db.close()
        self.studio.delete_profile(profile["id"])
        self.assertFalse(Path(sample["path"]).exists())

    def test_dictionary_and_segmentation(self):
        self.studio.save_reading("情報保障", "じょうほうほしょう")
        prepared = prepare_text("# 情報保障。\n\n長い説明。", self.studio.dictionary())
        self.assertEqual([x["text"] for x in segments(prepared)], ["じょうほうほしょう。", "長い説明。"])
        self.assertTrue(segments(prepared)[0]["paragraph_end"])
        long = "あ"*350
        self.assertTrue(all(len(x["text"]) <= 160 for x in segments(long)))

    def test_mock_model_audio_pipeline_export_and_cache(self):
        profile = self.studio.import_voice(str(self.source), "私", "こんにちは", True)
        model_dir = self.studio.store.root / "models" / "qwen06"
        model_dir.mkdir()
        (model_dir / "config.json").write_text('{"tts_model_type":"base"}')
        atomic_json(model_dir / "manifest.json", {"revision": "test", "files": {"config.json": digest(model_dir / "config.json")}})
        settings = self.studio.settings()
        job_id = "1"*32
        request_dir = self.studio.store.root / "jobs" / job_id
        request_dir.mkdir()
        job = {"id": job_id, "model_id": "qwen06", "profile_id": profile["id"],
               "settings": settings, "seed": 42}
        request = {"job": job, "root": str(self.studio.store.root), "sample": profile["samples"][0],
                   "segments": segments("最初の文。次の文。")}
        atomic_json(request_dir / "request.json", request)
        FakeEngine.calls = 0
        with patch("myvoice.worker.Qwen3TTSEngine", FakeEngine), patch.dict(os.environ, {"HF_HUB_OFFLINE": "1"}):
            work("synthesize", request_dir / "request.json")
            self.assertEqual(FakeEngine.calls, 2)
            work("synthesize", request_dir / "request.json")
            self.assertEqual(FakeEngine.calls, 2)
        state = json.loads((request_dir / "state.json").read_text())
        self.assertEqual(state["status"], "completed")
        self.assertGreater(analyze(state["output"])["duration"], 2)
        for fmt in ("wav", "mp3", "m4a"):
            target = self.root / f"result.{fmt}"
            export(state["output"], target, fmt)
            self.assertGreater(target.stat().st_size, 1000)

    def test_bad_input_and_missing_model(self):
        profile = self.studio.import_voice(str(self.source), "私", "こんにちは", True)
        with self.assertRaisesRegex(StudioError, "未導入"):
            self.studio.start_job("テスト", profile["id"], profile["samples"][0]["id"])
        bad = self.root / "bad.wav"
        bad.write_bytes(b"not an audio file")
        with self.assertRaises(StudioError):
            self.studio.import_voice(str(bad), "私", "こんにちは", True)

    def test_job_remains_cancellable_after_backend_restart(self):
        job = self.studio.store.new(type="synthesis", status="queued", progress=0,
                                    message="開始待ち", error="", output="")
        self.studio.store.put("job", job)
        job_dir = self.studio.store.root / "jobs" / job["id"]
        job_dir.mkdir()
        process = subprocess.Popen(["/bin/sleep", "20"], start_new_session=True)
        try:
            (job_dir / "pid").write_text(str(process.pid))
            atomic_json(job_dir / "state.json", {"status": "running", "progress": .3,
                                                  "message": "処理中"})
            restarted = Studio(self.studio.store.root)
            self.assertEqual(restarted.job(job["id"])["status"], "running")
            self.assertEqual(restarted.cancel(job["id"])["status"], "cancelled")
            restarted.store.db.close()
            process.wait(timeout=3)
        finally:
            if process.poll() is None:
                process.terminate()
                process.wait(timeout=3)

    def test_manual_model_import_checksums(self):
        source = self.root / "manual-model"
        source.mkdir()
        (source / "config.json").write_text('{"tts_model_type":"base"}')
        (source / "model.safetensors").write_bytes(b"test fixture")
        result = import_model(self.studio.store.root, "qwen06", source)
        self.assertEqual(verify_model(result["path"])["revision"], "manual-import")
        (Path(result["path"]) / "model.safetensors").write_bytes(b"changed")
        with self.assertRaisesRegex(StudioError, "破損"):
            verify_model(result["path"])

    def test_delete_history_removes_owned_audio_and_job(self):
        job = self.studio.store.new(type="synthesis", status="completed", progress=1)
        self.studio.store.put("job", job)
        job_dir = self.studio.store.root / "jobs" / job["id"]
        job_dir.mkdir()
        (job_dir / "state.json").write_text("{}")
        output = self.studio.store.root / "outputs" / f"{job['id']}.wav"
        tone(output, 1)
        history = self.studio.store.new(job_id=job["id"], profile_id="a" * 32,
                                        model_id="qwen06", text="履歴", path=str(output))
        self.studio.store.put("history", history)
        self.assertTrue(self.studio.delete_history(history["id"]))
        self.assertFalse(output.exists())
        self.assertFalse(job_dir.exists())
        self.assertEqual(self.studio.store.list("history"), [])
        self.assertEqual(self.studio.store.list("job"), [])


if __name__ == "__main__":
    unittest.main()
