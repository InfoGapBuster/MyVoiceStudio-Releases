import gc
import importlib.util
from pathlib import Path

from . import TTSEngine
from ..core import StudioError


class Qwen3TTSEngine(TTSEngine):
    """Adapter over documented mlx-audio load_model / generate only. No vendored model code."""
    def __init__(self):
        self.model = None

    def load_model(self, path):
        if importlib.util.find_spec("mlx_audio") is None:
            raise StudioError("MLX Audioが未導入です。アプリの実行環境を導入するか、同梱版をインストールしてください。")
        from mlx_audio.tts.utils import load_model
        self.model = load_model(str(Path(path).resolve()))

    def synthesize(self, text, reference, transcript, destination, seed):
        import mlx.core as mx
        import numpy as np
        import soundfile as sf
        mx.random.seed(seed)
        chunks = []
        for result in self.model.generate(text=text, ref_audio=str(reference), ref_text=transcript,
                                          lang_code="Japanese", max_tokens=2048, temperature=.7,
                                          verbose=False, stream=False):
            samples = np.asarray(result.audio, dtype=np.float32).reshape(-1)
            if not np.isfinite(samples).all():
                raise StudioError("生成音声に不正な値が含まれています。再生成してください。")
            chunks.append(samples)
        if not chunks:
            raise StudioError("モデルから音声が返されませんでした。短い文章で再試行してください。")
        samples = np.concatenate(chunks)
        if len(samples) == 0:
            raise StudioError("生成音声が空です。")
        sf.write(str(destination), samples, self.model.sample_rate, subtype="PCM_16")
        try:
            peak = round(mx.metal.get_peak_memory()/1024**3, 3)
        except (AttributeError, RuntimeError):
            peak = 0
        return {"peak_memory_gb": peak}

    def unload_model(self):
        self.model = None
        gc.collect()
        try:
            import mlx.core as mx
            mx.clear_cache()
        except ImportError:
            pass
