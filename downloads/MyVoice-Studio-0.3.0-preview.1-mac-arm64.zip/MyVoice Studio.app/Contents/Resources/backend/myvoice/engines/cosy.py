"""CosyVoice 3 adapter for the Apple Silicon MLX port."""
import gc
from pathlib import Path

from . import TTSEngine
from ..core import StudioError


def katakana(text):
    import pykakasi
    converter = pykakasi.kakasi()
    return "".join(part["kana"] for part in converter.convert(text))


class CosyVoice3Engine(TTSEngine):
    def __init__(self):
        self.model = None

    def load_model(self, path):
        from mlx_audio.tts.utils import load_model
        self.model = load_model(str(Path(path).resolve()))

    def synthesize(self, text, reference, transcript, destination, seed):
        import mlx.core as mx
        import numpy as np
        import soundfile as sf
        from mlx_audio.utils import load_audio

        with sf.SoundFile(str(reference)) as wav:
            if len(wav) / wav.samplerate > 30:
                raise StudioError("CosyVoice 3 の参照音声は30秒以内にしてください。")
        audio = load_audio(str(reference), sample_rate=self.model.sample_rate)
        mx.random.seed(seed)
        chunks = []
        peak = 0
        for result in self.model.generate(text=katakana(text), ref_audio=audio,
                                          ref_text=katakana(transcript), seed=seed,
                                          verbose=False, stream=False):
            samples = np.asarray(result.audio, dtype=np.float32).reshape(-1)
            if not np.isfinite(samples).all():
                raise StudioError("生成音声に不正な値が含まれています。")
            chunks.append(samples)
            peak = max(peak, getattr(result, "peak_memory_usage", 0) or 0)
        if not chunks or not any(len(chunk) for chunk in chunks):
            raise StudioError("モデルから音声が返されませんでした。")
        sf.write(str(destination), np.concatenate(chunks), self.model.sample_rate, subtype="PCM_16")
        return {"peak_memory_gb": peak}

    def unload_model(self):
        self.model = None
        gc.collect()
        try:
            import mlx.core as mx
            mx.clear_cache()
        except ImportError:
            pass
