"""Application layer. The UI talks to this object over a private JSON-lines pipe."""
from __future__ import annotations

import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import uuid

from .audio import analyze, export, normalize
from .core import Store, StudioError, identifier, local_file, number, prepare_text, segments, atomic_json
from .models import CATALOG, inspect, installed, model_info, import_model, model_path, runtime_ready, cosy_runtime


class Studio:
    def __init__(self, root):
        self.store = Store(root)
        self.workers = {}

    def overview(self):
        return {"profiles": self.store.list("profile"), "history": self.store.list("history"),
                "jobs": [self.job(j["id"]) for j in self.store.list("job")[:30]],
                "models": inspect(self.store.root), "dictionary": self.dictionary(),
                "settings": self.settings()}

    def settings(self):
        try:
            return self.store.get("settings", "default")
        except StudioError:
            return {"id": "default", "selected_model": "qwen06", "speed": 1.0, "pitch": 0.0,
                    "volume": 1.0, "sentence_gap": .25, "paragraph_gap": .6,
                    "ai_metadata": True}

    def save_settings(self, data):
        old = self.settings()
        if "selected_model" in data:
            model_info(data["selected_model"])
            old["selected_model"] = data["selected_model"]
        for key, low, high in (("speed", .5, 2), ("pitch", -6, 6), ("volume", .1, 2),
                               ("sentence_gap", 0, 3), ("paragraph_gap", 0, 5)):
            if key in data:
                old[key] = number(data[key], low, high)
        if "ai_metadata" in data:
            old["ai_metadata"] = bool(data["ai_metadata"])
        return self.store.put("settings", old)

    def dictionary(self):
        return {item["word"]: item["reading"] for item in self.store.list("reading")}

    def save_reading(self, word, reading):
        word, reading = str(word).strip(), str(reading).strip()
        if not 1 <= len(word) <= 50 or not 1 <= len(reading) <= 100:
            raise StudioError("単語は1〜50文字、読みは1〜100文字にしてください。")
        if not all("ぁ" <= c <= "ゖ" or c in "ー・ 　" for c in reading):
            raise StudioError("読みはひらがなで入力してください。")
        item = {"id": uuid.uuid5(uuid.NAMESPACE_DNS, word).hex, "word": word, "reading": reading}
        return self.store.put("reading", item)

    def delete_reading(self, word):
        self.store.delete("reading", uuid.uuid5(uuid.NAMESPACE_DNS, word).hex)
        return True

    def import_voice(self, path, name, transcript, consent, start=0, end=None, profile_id=None):
        if consent is not True:
            raise StudioError("ご本人の声、または利用許諾を得た声であることを確認してください。")
        source = local_file(path, {".wav", ".mp3", ".m4a", ".flac"})
        name, transcript = str(name).strip(), str(transcript).strip()
        if not 1 <= len(name) <= 80 or not 1 <= len(transcript) <= 2000:
            raise StudioError("名前と録音内容の書き起こしを入力してください。")
        profile = self.store.get("profile", identifier(profile_id)) if profile_id else self.store.new(
            name=name, language="Japanese", samples=[], rights_confirmed=True, training_history=[])
        sample_id = uuid.uuid4().hex
        output = self.store.root / "voices" / f"{sample_id}.wav"
        try:
            stats = normalize(source, output, start, end)
            sample = {"id": sample_id, "path": str(output), "transcript": transcript,
                      "created": time.time(), "duration": stats["duration"], "analysis": stats,
                             "language": "Japanese", "compatible_engines": ["qwen06", "qwen17", "cosy3"]}
            profile["samples"].append(sample)
            self.store.put("profile", profile)
            if source.is_relative_to(self.store.root / "recordings"):
                source.unlink(missing_ok=True)
            return profile
        except Exception:
            output.unlink(missing_ok=True)
            raise

    def update_transcript(self, profile_id, sample_id, transcript):
        profile = self.store.get("profile", identifier(profile_id))
        transcript = str(transcript).strip()
        if not 1 <= len(transcript) <= 2000:
            raise StudioError("書き起こしを入力してください。")
        sample = next((x for x in profile["samples"] if x["id"] == identifier(sample_id)), None)
        if sample is None:
            raise StudioError("音声サンプルが見つかりません。")
        sample["transcript"] = transcript
        return self.store.put("profile", profile)

    def delete_profile(self, profile_id):
        profile = self.store.get("profile", identifier(profile_id))
        if any(self.job(j["id"])["status"] in ("running", "queued") and j.get("profile_id") == profile_id
               for j in self.store.list("job")):
            raise StudioError("この声を使う処理が進行中です。先に処理を中止してください。")
        for sample in profile["samples"]:
            Path(sample["path"]).unlink(missing_ok=True)
        # Purge generated voice outputs and caches linked to this profile.
        for entry in self.store.list("history"):
            if entry["profile_id"] == profile_id:
                self.delete_history(entry["id"])
        shutil.rmtree(self.store.root / "cache" / profile_id, ignore_errors=True)
        self.store.delete("profile", profile_id)
        return True

    def import_text(self, path):
        source = local_file(path, {".txt", ".md"}, 5 * 1024 * 1024)
        try:
            text = source.read_text(encoding="utf-8-sig")
        except UnicodeError:
            raise StudioError("原稿はUTF-8で保存してください。") from None
        return {"text": text, "segments": segments(prepare_text(text, self.dictionary()))}

    def start_job(self, text, profile_id, sample_id, model_id=None, seed=None):
        text = str(text).strip()
        if not 1 <= len(text) <= 30000:
            raise StudioError("原稿は1〜30,000文字にしてください。")
        profile = self.store.get("profile", identifier(profile_id))
        sample = next((x for x in profile["samples"] if x["id"] == identifier(sample_id)), None)
        if not sample or not sample["transcript"]:
            raise StudioError("書き起こし付きの参照音声を選んでください。")
        model_id = model_id or self.settings()["selected_model"]
        info = model_info(model_id)
        if model_id == "cosy3" and sample["duration"] > 30:
            raise StudioError("CosyVoice 3 の参照音声は30秒以内にしてください。")
        try:
            memory_gb = int(subprocess.check_output(["/usr/sbin/sysctl", "-n", "hw.memsize"],
                                                     text=True, timeout=3,
                                                     stderr=subprocess.DEVNULL).strip()) / 1024**3
            if memory_gb < info["memory_gb"] + 3:
                raise StudioError("このモデルを動かすにはメモリが足りません。軽量モデルを選んでください。")
        except (FileNotFoundError, subprocess.SubprocessError, ValueError):
            pass
        if not installed(self.store.root, model_id):
            raise StudioError("モデルが未導入です。設定からダウンロードしてください。")
        if not runtime_ready(self.store.root, model_id):
            raise StudioError("このモデルの実行環境がありません。設定から取得してください。")
        if any(self.job(j["id"])["status"] in ("running", "queued") for j in self.store.list("job")[:10]):
            raise StudioError("現在の処理が終わるか中止してから開始してください。")
        if seed is None:
            seed = int.from_bytes(os.urandom(4), "big")
        seed = int(number(seed, 0, 2**32-1))
        prepared = prepare_text(text, self.dictionary())
        parts = segments(prepared)
        if not parts:
            raise StudioError("読み上げ可能な文章がありません。原稿を確認してください。")
        job = self.store.new(type="synthesis", status="queued", progress=0, message="開始待ち",
                             profile_id=profile_id, sample_id=sample_id, model_id=model_id,
                             text=text, prepared_text=prepared, segment_count=len(parts), seed=seed,
                             settings=self.settings(), output="", error="")
        job_dir = self.store.root / "jobs" / job["id"]
        job_dir.mkdir(mode=0o700)
        atomic_json(job_dir / "request.json", {"job": job, "segments": parts, "sample": sample,
                     "root": str(self.store.root)})
        self.store.put("job", job)
        self._launch(job["id"], "synthesize")
        return job

    def download_model(self, model_id):
        info = model_info(model_id)
        if any(self.job(j["id"])["status"] in ("running", "queued") for j in self.store.list("job")[:10]):
            raise StudioError("進行中の処理が終わってからモデルを取得してください。")
        job = self.store.new(type="download", status="queued", progress=0, message="開始待ち",
                             model_id=model_id, output="", error="")
        job_dir = self.store.root / "jobs" / job["id"]
        job_dir.mkdir(mode=0o700)
        atomic_json(job_dir / "request.json", {"job": job, "root": str(self.store.root)})
        self.store.put("job", job)
        self._launch(job["id"], "download")
        return job

    def _launch(self, job_id, action):
        env = os.environ.copy()
        env.update({"HF_HUB_OFFLINE": "1" if action == "synthesize" else "0",
                    "TRANSFORMERS_OFFLINE": "1" if action == "synthesize" else "0",
                    "HF_HUB_DISABLE_TELEMETRY": "1", "NO_PROXY": "*"})
        env["HF_HOME"] = str(self.store.root / "runtime" / "huggingface")
        request_path = self.store.root / "jobs" / job_id / "request.json"
        request = json.loads(request_path.read_text(encoding="utf-8"))
        python = (cosy_runtime(self.store.root) / "bin" / "python"
                  if action == "synthesize" and request["job"]["model_id"] == "cosy3"
                  else sys.executable)
        cmd = [str(python), "-m", "myvoice.worker", action,
               str(self.store.root / "jobs" / job_id / "request.json")]
        log = open(self.store.root / "jobs" / job_id / "worker.log", "ab")
        try:
            proc = subprocess.Popen(cmd, stdin=subprocess.DEVNULL, stdout=log, stderr=log,
                                    env=env, start_new_session=True)
        finally:
            log.close()
        self.workers[job_id] = proc
        (self.store.root / "jobs" / job_id / "pid").write_text(str(proc.pid), encoding="ascii")

    def _worker_pid(self, job_id):
        try:
            pid = int((self.store.root / "jobs" / job_id / "pid").read_text(encoding="ascii"))
            if pid <= 0:
                return None
            os.kill(pid, 0)
            return pid
        except (FileNotFoundError, ValueError, ProcessLookupError, PermissionError):
            return None

    def job(self, job_id):
        job = self.store.get("job", identifier(job_id))
        job_dir = self.store.root / "jobs" / job_id
        state_path = job_dir / "state.json"
        if state_path.is_file():
            state = json.loads(state_path.read_text(encoding="utf-8"))
            job.update(state)
            if state["status"] == "running" and self._worker_pid(job_id) is None:
                job.update(status="failed", error="処理が予期せず終了しました。ログを確認してください。")
            if state["status"] in ("completed", "failed", "cancelled"):
                self.store.put("job", job)
                if state["status"] == "completed" and job["type"] == "synthesis":
                    if not any(h["job_id"] == job_id for h in self.store.list("history")):
                        self.store.put("history", self.store.new(job_id=job_id, profile_id=job["profile_id"],
                            model_id=job["model_id"], text=job["text"], path=state["output"],
                            settings=job["settings"], seed=job["seed"],
                            elapsed_seconds=state.get("elapsed_seconds", 0),
                            peak_memory_gb=state.get("peak_memory_gb", 0)))
        elif job["status"] in ("queued", "running"):
            if self._worker_pid(job_id) is None and time.time() - job["created"] > 3:
                job.update(status="failed", error="処理が予期せず終了しました。ログを確認してください。")
                self.store.put("job", job)
        if job["status"] == "failed":
            self.store.put("job", job)
        return job

    def cancel(self, job_id):
        job = self.job(job_id)
        if job["status"] not in ("queued", "running"):
            return job
        pid = self._worker_pid(job_id)
        if pid:
            import signal
            try:
                os.killpg(pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
        state = {"status": "cancelled", "message": "中止しました", "progress": job["progress"]}
        atomic_json(self.store.root / "jobs" / job_id / "state.json", state)
        job.update(state)
        return self.store.put("job", job)

    def export_audio(self, history_id, destination, format):
        record = self.store.get("history", identifier(history_id))
        source = Path(record["path"]).resolve()
        if not source.is_relative_to(self.store.root / "outputs") or not source.is_file():
            raise StudioError("生成音声が見つかりません。")
        destination = Path(destination).expanduser().resolve()
        if destination.suffix.lower() != f".{format}":
            raise StudioError("保存先の拡張子と形式が一致しません。")
        if destination == source:
            raise StudioError("別の保存先を選んでください。")
        export(source, destination, format, self.settings()["ai_metadata"])
        return {"path": str(destination)}

    def delete_history(self, history_id):
        record = self.store.get("history", identifier(history_id))
        output = Path(record["path"]).resolve()
        if output.is_relative_to(self.store.root / "outputs"):
            output.unlink(missing_ok=True)
        job_id = identifier(record["job_id"])
        shutil.rmtree(self.store.root / "jobs" / job_id, ignore_errors=True)
        self.store.delete("job", job_id)
        self.store.delete("history", history_id)
        return True

    def delete_model(self, model_id):
        model_info(model_id)
        if model_path(self.store.root, model_id) != self.store.root / "models" / model_id:
            raise StudioError("このモデルはアプリに同梱されています。削除するにはアプリを入れ替えてください。")
        if any(self.job(j["id"])["status"] in ("queued", "running") and j.get("model_id") == model_id
               for j in self.store.list("job")):
            raise StudioError("使用中のモデルは削除できません。")
        shutil.rmtree(self.store.root / "models" / model_id, ignore_errors=True)
        return True

    def import_model(self, model_id, path):
        if any(self.job(j["id"])["status"] in ("running", "queued") for j in self.store.list("job")):
            raise StudioError("進行中の処理が終わってからモデルを追加してください。")
        return import_model(self.store.root, model_id, path)


def dispatch(studio, message):
    op = message.get("op")
    data = message.get("data") or {}
    if not isinstance(data, dict):
        raise StudioError("リクエスト形式が不正です。")
    methods = {
        "overview": studio.overview, "settings": studio.save_settings,
        "save_reading": studio.save_reading, "delete_reading": studio.delete_reading,
        "import_voice": studio.import_voice, "update_transcript": studio.update_transcript,
        "delete_profile": studio.delete_profile, "import_text": studio.import_text,
        "start_job": studio.start_job, "download_model": studio.download_model,
        "job": studio.job, "cancel": studio.cancel,
        "export": studio.export_audio, "delete_model": studio.delete_model,
        "delete_history": studio.delete_history,
        "import_model": studio.import_model,
    }
    if op not in methods:
        raise StudioError("不明な操作です。")
    try:
        return methods[op](**data)
    except TypeError:
        raise StudioError("操作に必要な入力が不足しています。") from None


def main():
    root = os.environ.get("MYVOICE_DATA", str(Path.home() / "Library" / "Application Support" / "MyVoice Studio"))
    studio = Studio(root)
    for line in sys.stdin:
        try:
            request = json.loads(line)
            result = {"id": request.get("id"), "ok": True, "data": dispatch(studio, request)}
        except StudioError as exc:
            result = {"id": request.get("id") if "request" in locals() else None, "ok": False, "error": str(exc)}
        except Exception as exc:
            print(f"Unexpected backend error: {exc!r}", file=sys.stderr)
            result = {"id": request.get("id") if "request" in locals() else None, "ok": False,
                      "error": "内部エラーが発生しました。ログを確認してください。"}
        print(json.dumps(result, ensure_ascii=False, allow_nan=False), flush=True)
