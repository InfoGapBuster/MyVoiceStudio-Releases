import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import venv

from .core import StudioError, digest, atomic_json


CATALOG = {
    "qwen06": {"name": "Qwen3-TTS 0.6B Base · 軽量", "repo": "mlx-community/Qwen3-TTS-12Hz-0.6B-Base-4bit", "memory_gb": 6, "license": "Apache-2.0", "engine": "qwen", "download_gb": 1.5},
    "qwen17": {"name": "Qwen3-TTS 1.7B Base · 高品質", "repo": "mlx-community/Qwen3-TTS-12Hz-1.7B-Base-4bit", "memory_gb": 8, "license": "Apache-2.0", "engine": "qwen", "download_gb": 2.5},
    "cosy3": {"name": "CosyVoice 3 0.5B · MLX 4bit", "repo": "mlx-community/Fun-CosyVoice3-0.5B-2512-4bit", "memory_gb": 6, "license": "Apache-2.0", "engine": "cosy3", "download_gb": 2.3}
}


def cosy_runtime(root):
    return Path(root) / "runtime" / "cosy3-venv"


def runtime_ready(root, key):
    if CATALOG[key]["engine"] == "cosy3":
        runtime = cosy_runtime(root)
        return ((runtime / "ready").is_file() and (runtime / "bin" / "python").is_file()
                and cosy_tokenizer_ready(root))
    return importlib.util.find_spec("mlx_audio") is not None


def cosy_tokenizer_ready(root):
    return (Path(root) / "runtime" / "cosy3-tokenizer-ready").is_file()


def install_cosy_runtime(root, progress):
    runtime = cosy_runtime(root)
    if (runtime / "ready").is_file() and (runtime / "bin" / "python").is_file():
        return
    progress(.03, "CosyVoice 3 の実行環境を導入中")
    runtime.parent.mkdir(parents=True, exist_ok=True)
    # A separate environment keeps mlx-audio-plus from replacing Qwen's mlx-audio package.
    venv.EnvBuilder(with_pip=True).create(runtime)
    try:
        subprocess.run([str(runtime / "bin" / "python"), "-m", "pip", "install",
                        "mlx-audio-plus[tts]==0.1.8", "pykakasi"], check=True)
        subprocess.run([str(runtime / "bin" / "python"), "-c",
                        "import mlx_audio, pykakasi, soundfile"], check=True)
    except subprocess.CalledProcessError:
        raise StudioError("CosyVoice 3 の実行環境を導入できませんでした。worker.logを確認してください。") from None
    (runtime / "ready").write_text("mlx-audio-plus\n", encoding="utf-8")


def model_info(key):
    if key not in CATALOG:
        raise StudioError("未登録のモデルです。モデル一覧から選んでください。")
    return CATALOG[key]


def model_path(root, key):
    """Prefer a user-installed model; otherwise use a read-only app-bundled model."""
    local = Path(root) / "models" / key
    if (local / "manifest.json").is_file():
        return local
    bundled_root = os.environ.get("MYVOICE_BUNDLED_MODELS")
    if bundled_root:
        bundled = Path(bundled_root) / key
        if (bundled / "manifest.json").is_file():
            return bundled
    return local


def installed(root, key):
    return (model_path(root, key) / "manifest.json").is_file()


def inspect(root):
    from .engines.qwen import Qwen3TTSEngine
    from .engines.cosy import CosyVoice3Engine
    rows = []
    for key, info in CATALOG.items():
        path = model_path(root, key)
        manifest = json.loads((path / "manifest.json").read_text()) if installed(root, key) else {}
        rows.append({"id": key, **info, "installed": bool(manifest), "runtime_ready": runtime_ready(root, key),
                     "license": manifest.get("license", info["license"]),
                     "revision": manifest.get("revision", ""), "bytes": manifest.get("bytes", 0),
                     "bundled": bool(os.environ.get("MYVOICE_BUNDLED_MODELS") and
                                     path == Path(os.environ["MYVOICE_BUNDLED_MODELS"]) / key),
                     "capabilities": (Qwen3TTSEngine() if info["engine"] == "qwen" else CosyVoice3Engine()).get_capabilities()})
    return rows


def verify_model(path, check_hash=True):
    path = Path(path).resolve()
    manifest = json.loads((path / "manifest.json").read_text())
    for name, expected in manifest["files"].items():
        file = (path / name).resolve()
        if not file.is_relative_to(path) or not file.is_file() or file.is_symlink():
            raise StudioError("モデル内のパスが不正です。削除して再取得してください。")
        if check_hash and digest(file) != expected:
            raise StudioError("モデルが破損しています。削除して再取得してください。")
    config = json.loads((path / "config.json").read_text())
    if manifest.get("repo") == CATALOG["cosy3"]["repo"]:
        if config.get("model_type") != "cosyvoice3":
            raise StudioError("CosyVoice 3 のモデルではありません。")
    elif config.get("tts_model_type") != "base":
        raise StudioError("Voice CloningにはBaseモデルが必要です。")
    return manifest


def download(root, key, progress):
    info = model_info(key)
    if shutil.disk_usage(root).free < 8 * 1024**3:
        raise StudioError("モデル取得には8GB以上の空き容量を確保してください。")
    if info["engine"] == "cosy3":
        install_cosy_runtime(root, progress)
    try:
        from huggingface_hub import HfApi, snapshot_download
    except ImportError:
        raise StudioError("モデル取得用ライブラリがありません。アプリの実行環境を導入するか、同梱版をインストールしてください。") from None
    if key == "cosy3":
        progress(.08, "音声トークナイザーを取得中")
        try:
            snapshot_download("mlx-community/S3TokenizerV3",
                              allow_patterns=["*.json", "*.safetensors"])
        except Exception:
            raise StudioError("CosyVoice 3 の音声トークナイザーを取得できませんでした。") from None
        marker = Path(root) / "runtime" / "cosy3-tokenizer-ready"
        marker.parent.mkdir(parents=True, exist_ok=True)
        marker.write_text("mlx-community/S3TokenizerV3\n", encoding="utf-8")
    progress(.12 if key == "cosy3" else .02, "モデルの版・サイズを確認中")
    api = HfApi(token=False)
    try:
        remote = api.model_info(info["repo"], files_metadata=True, token=False)
    except Exception:
        raise StudioError("モデルの公開先に接続できません。ネットワーク接続とDNSを確認してください。") from None
    published_license = getattr(remote.card_data, "license", None) if remote.card_data else None
    if published_license and published_license.lower() != "apache-2.0":
        raise StudioError("モデルのライセンスが想定と異なります。取得前に利用条件を確認してください。")
    path = Path(root) / "models" / key
    path.mkdir(exist_ok=True)
    # Select data only; never download Python, pickle, or executable code.
    patterns = ["*.json", "*.safetensors", "*.txt", "*.model", "*.tiktoken", "*.md", "LICENSE*"]
    try:
        snapshot_download(info["repo"], revision=remote.sha, local_dir=path,
                          allow_patterns=patterns, token=False, max_workers=2)
    except Exception:
        raise StudioError("モデルの取得に失敗しました。ネットワークと空き容量を確認して再試行してください。") from None
    progress(.9, "モデルの整合性を記録中")
    files = {str(f.relative_to(path)): digest(f) for f in path.rglob("*")
             if f.is_file() and ".cache" not in f.parts and f.name != "manifest.json"}
    if "config.json" not in files or not any(x.endswith(".safetensors") for x in files):
        raise StudioError("モデルのダウンロードが完了していません。再試行してください。")
    atomic_json(path / "manifest.json", {"repo": info["repo"], "revision": remote.sha,
                "license": info["license"], "files": files,
                "bytes": sum((path / f).stat().st_size for f in files)})
    try:
        verify_model(path)
    except Exception:
        (path / "manifest.json").unlink(missing_ok=True)
        raise


def import_model(root, key, source):
    """Import a manually downloaded MLX model without executing repository code."""
    info = model_info(key)
    if info["engine"] == "cosy3" and not runtime_ready(root, key):
        raise StudioError("先に設定画面の「取得」でCosyVoice 3の実行環境を導入してください。")
    source = Path(source).expanduser().resolve(strict=True)
    if not source.is_dir() or source.is_relative_to(Path(root).resolve()):
        raise StudioError("別の場所にあるモデルフォルダを選択してください。")
    config_path = source / "config.json"
    expected_type = "cosyvoice3" if key == "cosy3" else "base"
    config_key = "model_type" if key == "cosy3" else "tts_model_type"
    if not config_path.is_file() or json.loads(config_path.read_text()).get(config_key) != expected_type:
        raise StudioError("選択した種類のモデルフォルダを選択してください。")
    allowed = {".json", ".safetensors", ".txt", ".model", ".tiktoken", ".md"}
    files = [p for p in source.rglob("*") if p.is_file() and p.suffix.lower() in allowed
             and ".cache" not in p.parts]
    if not any(p.suffix == ".safetensors" for p in files):
        raise StudioError("モデルの重みファイルがありません。")
    if any(p.is_symlink() or not p.resolve().is_relative_to(source) for p in files):
        raise StudioError("リンクを含むモデルは読み込めません。実ファイルで取得してください。")
    size = sum(p.stat().st_size for p in files)
    if size > 12 * 1024**3:
        raise StudioError("モデルフォルダが大きすぎます。")
    target = Path(root) / "models" / key
    temporary = Path(root) / "models" / f".{key}-import"
    if temporary.exists():
        shutil.rmtree(temporary)
    temporary.mkdir()
    try:
        checksums = {}
        for file in files:
            relative = file.relative_to(source)
            destination = temporary / relative
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(file, destination)
            checksums[str(relative)] = digest(destination)
        atomic_json(temporary / "manifest.json", {"repo": info["repo"],
                    "revision": "manual-import", "license": "手動追加: 利用条件を要確認",
                    "files": checksums, "bytes": size})
        verify_model(temporary)
        if target.exists():
            shutil.rmtree(target)
        temporary.rename(target)
    except Exception:
        shutil.rmtree(temporary, ignore_errors=True)
        raise
    return {"path": str(target), "bytes": size}
